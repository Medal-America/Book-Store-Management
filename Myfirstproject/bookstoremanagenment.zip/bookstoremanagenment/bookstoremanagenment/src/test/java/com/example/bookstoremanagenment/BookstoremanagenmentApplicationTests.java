package com.example.bookstoremanagenment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoremanagenmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
