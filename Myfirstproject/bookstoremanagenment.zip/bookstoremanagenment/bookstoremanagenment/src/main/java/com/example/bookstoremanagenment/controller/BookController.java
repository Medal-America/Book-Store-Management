package com.example.bookstoremanagenment.controller;

import com.example.bookstoremanagenment.entity.Book;
import com.example.bookstoremanagenment.entity.MyBookList;
import com.example.bookstoremanagenment.service.BookService;
import com.example.bookstoremanagenment.service.MyBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class BookController {
   @Autowired
   private BookService service;
    @GetMapping("/")
    public String home() {
        return "home";
    }


    @GetMapping("/book_register")
    public String bookRegister() {
        return "bookRegister";
    }
    @GetMapping("/available_books")
    public ModelAndView getAllBook() {
        List<Book> list = service.getAllBook();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("bookList");
        modelAndView.addObject("book",list);
        return modelAndView;
    }
    @PostMapping("/save")
    public String addBook(@ModelAttribute Book book) {
        service.save(book);
        return "redirect:/available_books";
    }
//    @PostMapping("/save")
//    public String myBookList(@RequestBody MyBookList myBookList) {
//        service.save(myBookList);
//        return "bookList";
//    }

    @GetMapping("/my_books")
    public String getAllBooks(Model model) {
        List<Book> list= service.getAllBook();
         model.addAttribute("MyBooks",list);
        return "myBooks";
    }


}
