package com.example.bookstoremanagenment.controller;

import com.example.bookstoremanagenment.entity.Book;
import com.example.bookstoremanagenment.entity.MyBookList;
import com.example.bookstoremanagenment.service.MyBookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class MyBookController {

   private MyBookService myBookService;
    @RequestMapping("/deleteMylist/{id}")
        public String deleteMyList( @PathVariable("id") int id) {
        myBookService.deleteById(id);
            return "redirect:/my_books";
        }


    @GetMapping("/mylist")
    public String getAllBooks(Model model) {
        List<MyBookList> list= myBookService.findAllMyBooks();
        model.addAttribute("MyBooks",list);
        return "redirect: /bookList";
        }
    }

