package com.example.bookstoremanagenment.service;

import com.example.bookstoremanagenment.entity.Book;
import com.example.bookstoremanagenment.entity.MyBookList;
import com.example.bookstoremanagenment.repository.BookRepository;
import com.example.bookstoremanagenment.repository.MyBookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyBookService {
    @Autowired
    private static MyBookRepository myBookRepository;

    public static List<MyBookList> getAllMyBook() {
        return myBookRepository.findAll();
    }

    public void save(MyBookList myBookList) {
        myBookRepository.save(myBookList);
    }
    public List<MyBookList> findAllMyBooks() {
        return myBookRepository.findAll();
    }
    public void deleteById(int id) {
        myBookRepository.deleteById(id);
    }

}

